#include"agent_findfood.h"
//一个寻找食物生成最短路径的函数
/*
这个函数分为两个部分：
第一部分为寻找距离当前瓦片最近一个存在食物的瓦片（非权值和即距离最近，仅为下标最近）
第二部分为生成距离该瓦片权值和(即距离)最近的一条路径。
*/

//模拟小人环顾四周看食物的动作,step变量是距离小人所在瓦片的步数传入0即可,predir是来的方向，比如若为0(北方)就不再向0(北方)遍历，若为3(西方)，就不再向3(西方)遍历
int stepP=0;
int tmpStepP=0;
int lookAroundForFood(MapChunk *m,person *h,int beginP,int predir,int step)
{
    tmpStepP=step;//先记录步数
    int targetP=-1;//有食物的瓦片的下标值

    if(m->Tiles[beginP].foodNumber>0)
    {
        return beginP;
    }

    if(step==0)
    {
        
        if(beginP+ListDirection[0]>-1)
        {
            targetP=lookAroundForFood(m,h,beginP+ListDirection[0],step+1,2);
        }
        if((beginP+ListDirection[1])%9!=0)
        {
            if(targetP==-1)//如果上个方向没找到
            {
                targetP=lookAroundForFood(m,h,beginP+ListDirection[1],step+1,3);
            }
            else
            {
                int tmpP=lookAroundForFood(m,h,beginP+ListDirection[1],step+1,3);
                IntIndexExchange(step,tmpStepP,targetP,tmpP);
            }
        }
        if(beginP+ListDirection[2]<81)
        {
            if(targetP==-1)//如果上个方向没找到
            {
                targetP=lookAroundForFood(m,h,beginP+ListDirection[2],step+1,0);
            }
            else
            {
                int tmpP=lookAroundForFood(m,h,beginP+ListDirection[2],step+1,0);
                IntIndexExchange(step,tmpStepP,targetP,tmpP);
            }
        }
        if((beginP+ListDirection[3])%9!=8&&(beginP+ListDirection[3])!=-1)
        {
            if(targetP==-1)//如果上个方向没找到
            {
                targetP=lookAroundForFood(m,h,beginP+ListDirection[3],step+1,1);
            }
            else
            {
                int tmpP=lookAroundForFood(m,h,beginP+ListDirection[3],step+1,1);
                IntIndexExchange(step,tmpStepP,targetP,tmpP);
            }
        }
    }
    else
    {
        int d=0;
        while(d<4)
        {
            if(d==predir)
            {
                continue;
            }
            switch(d)
            {
                case 0:if(beginP+ListDirection[0]>-1)
                {targetP=lookAroundForFood(m,h,beginP+ListDirection[0],step+1,2);}break;
                case 1:if((beginP+ListDirection[1])%9!=0)
                    {
                        if(targetP==-1)//如果上个方向没找到
                        {
                            targetP=lookAroundForFood(m,h,beginP+ListDirection[1],step+1,3);
                        }
                        else
                        {
                            int tmpP=lookAroundForFood(m,h,beginP+ListDirection[1],step+1,3);
                            IntIndexExchange(step,tmpStepP,targetP,tmpP);
                        }
                    }
                break;
                case 2:if(beginP+ListDirection[2]<81)
                        {
                        if(targetP==-1)//如果上个方向没找到
                        {
                            targetP=lookAroundForFood(m,h,beginP+ListDirection[2],step+1,0);
                        }
                        else
                        {
                            int tmpP=lookAroundForFood(m,h,beginP+ListDirection[2],step+1,0);
                            IntIndexExchange(step,tmpStepP,targetP,tmpP);
                        }
                        }break;
                case 3:if((beginP+ListDirection[3])%9!=8&&(beginP+ListDirection[3])!=-1)
                        {
                        if(targetP==-1)//如果上个方向没找到
                        {
                            targetP=lookAroundForFood(m,h,beginP+ListDirection[3],step+1,1);
                        }
                        else
                        {
                            int tmpP=lookAroundForFood(m,h,beginP+ListDirection[3],step+1,1);
                            IntIndexExchange(step,tmpStepP,targetP,tmpP);
                        }
                        }break;
            }
            d++;
        }
    }
    return targetP;
};

/*
寻找食物的函数开发结束了，但是这里还需要两个优化：
1.当stepP!=0时，不知是否会重复的遍历某个格子去寻找食物
2.根据视野进行食物的搜寻
*/



positionList *findFood(MapChunk *m,person *h,Position begin)
{
    Position (*pre)[9];
    
    tile tilemap[9][9];
    //开始映射
    for(int i=0;i<81;i++)
    {
        Position p=tilePositionCalculate(i);
        tilemap[p.y][p.x]=m->Tiles[i];
    }

    int targetList=PositionToList(begin);
    targetList=lookAroundForFood(m,h,targetList,-1);//得到有食物的瓦片的瓦片列表下标
    
    Position end=tilePositionCalculate(targetList);
    
    pre=originDijikstra_pret(tilemap,begin);
    positionList *path=getPath(pre,begin,end);//得到路径


    //如果路径不存在，返回空指针，打印日志
    if(path==nullptr)
    {
        cout<<"指针不存在";
        printPeopleDontHavePath(h->name);
        return path;
    }
    return path;
}