/*
本文件作用是开发过程中的一些小工具
包含了
bool judgeMoreTen(int x);//判断是否大于10
bool judgeMoreHundred(int x);//判断是否大于100
bool judeMoreTenLessHundred(int x);//判断是否大于10小于100
int judgeNumberDigit(int number);//判断数字位数的函数
string printSpaceForThreeDigitFormal_self(int number);//如果位数小于3位，为了打印出来的垂直效果美观，进行补全然后打印
int numberAddOne(int number);//对数据进行自增操作
struct Position//一个坐标结构体，包含xy坐标
Position tilePositionCalculate(int position);//根据瓦片列表中瓦片的下标计算该瓦片的position
*/


#ifndef TOOL_H
#define TOOL_H

#include<iostream>
#include<string>
using namespace std;

bool judgeMoreTen(int x);//判断是否大于10
bool judgeMoreHundred(int x);//判断是否大于100
bool judeMoreTenLessHundred(int x);//判断是否大于10小于100(喵的，用了半天函数名拼写错了)
int judgeNumberDigit(int number);//判断数字位数的函数
string printSpaceForThreeDigitFormal_self(int number);//如果位数小于3位，为了打印出来的垂直效果美观，进行补全然后打印,主要为了打印空格
int numberAddOne(int number);//对数据进行自增操作，为了防止大规模错误，准备多设置几个这种函数，改的时候只要改函数，大量的错误一步搞定(学到就是赚到！！！)
//以下是一个坐标结构体，包含xy坐标
struct Position
{
    int x;
    int y;
};

Position tilePositionCalculate(int position);//根据瓦片列表中瓦片的下标计算该瓦片的position


#endif