#include"../ToolH/tool.h"
using namespace std;

bool judgeMoreTen(int x)//判断是否大于10
{
    if(x>=10)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};


bool judgeMoreHundred(int x)//判断是否大于100
{
    if(x>=100)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};


bool judeMoreTenLessHundred(int x)//判断是否大于10小于100
{
    if(x>=10&&x<100)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};

int judgeNumberDigit(int number)//判断数字位数的函数
{
    int digit=0;
    while(number>0)
    {
        number/=10;
        digit++;
    }
    return digit;
};

string printSpaceForThreeDigitFormal_self(int number)//如果位数小于3位，为了打印出来的垂直效果美观，进行补全然后打印,主要为了打印空格
{
    string s="";
    int digit=judgeNumberDigit(number);
    while(digit<3)
    {
        s+=" ";
        digit++;
    }
    return s;
};

int numberAddOne(int number)//对数据进行自增操作，为了防止大规模错误，准备多设置几个这种函数，改的时候只要改函数，大量的错误一步搞定(学到就是赚到！！！)
{
    number++;
    return number;
};

Position tilePositionCalculate(int position)//根据瓦片列表中瓦片的下标计算该瓦片的position
{
    /*
    注意，这个函数一开始写错了，现在已经改过来了
    这个函数用于整型position从0开始映射到二维Position的
    第一个下标--y和第二个下标--x
    */
    Position p;
    p.x=position%9;
    p.y=position/9;
    return p;
}