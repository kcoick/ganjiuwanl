#include"../narratorH/narrator.h"
#include<iostream>
using namespace std;


void printPartingLine()//行动分割线
{
    cout<<endl;
    cout<<"----------------------------------------------------------------------------------------------------------------";
    cout<<endl;
};

void printMapCuttingLineLeft()//地图分割线(左)
{
    cout<<"|";
};
void printMapCuttingRight()//地图分割线(右)
{
    cout<<"|";
};
void printMapCuttingup()//地图分割线(上)
{
    cout<<"-------";
};
void printMapCuttingdown()//地图分割线(下)
{
    cout<<"-------";
};

void printMapCell(string name,int position,bool Enter)//打印地图中的一个小格子，包含了打印分割线的功能和回车换行功能
{
    //先进行是否是第一行的判断
    if(position==0)
    {
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        cout<<endl;
    }
    printMapCuttingLineLeft();
    cout<<name<<position<<printSpaceForThreeDigitFormal_self(position);
    printMapCuttingRight();
    if(Enter)
    {
        cout<<endl;
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        printMapCuttingup();
        cout<<endl;
    }
};



//-----------这是一些关于小人的解释性旁白，或者说日志---------------------

void printPeoplePositionChange(std::string name,Position begin,Position end)//打印小人的位置变化
{
    cout<<endl;

    cout<<name<<"从";
    cout<<"x:"<<begin.x<<",y:"<<begin.y<<",";
    cout<<"移动到了：";
    cout<<"x:"<<end.x<<",y:"<<end.y<<",";

    cout<<endl;
};

void printPeopleDontHavePath(std::string name)//打印小人无路可达终点的日志
{
    cout<<endl;

    cout<<name<<"说：我chove，无路可走";

    cout<<endl;
};

void printPeoplePosition(std::string name,Position position)//打印小人的位置日志，可与别的日志组合使用
{
    cout<<endl;

    cout<<name<<"在";
    cout<<"x:"<<position.x<<",y"<<position.y;

    cout<<endl;
}
//-----------这里是小人旁白或者说日志的结束------------------------------
