/*
    注意，这里新学习了一种返回二维数组指针的方法，如果忘了，记得去查查这个：
struct Point { int x; int y; };

Point (*create2D())[3]
{
    // 分配2个元素，每个是 Point[3]
    Point(*p)[3] = new Point[2][3]{
        { {1,1}, {2,2}, {3,3} },
        { {4,4}, {5,5}, {6,6} }
    };
    return p;
}

int main()
{
    Point(*ptr)[3] = create2D();
    printf("%d\n", ptr[0][1].x);

    // 必须手动释放！
    delete[] ptr;
    return 0;
}
*/

#include"DijistraSelf.h"
Position (*originDijikstra_pret(tile tilemap[][9],Position peoplePosition))[9]
{
    cout<<"进入迪杰斯特拉函数了";
    const int INF=INT_MAX/2;
    int dist[9][9];//当前最短路径,注意，在实现过程中第一个为行数，列的值，第二个为列数，行的值
    Position (*pret)[9]=new Position[9][9];//前一个瓦片的位置
    bool visited[9][9]={false};//当前顶点是否访问过,避免浪费时间
    //对dist和visited进行初始化
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<9;j++)
        {
            dist[i][j]=INF;
        }
    }
    dist[peoplePosition.y][peoplePosition.x]=0;
    //开始求每个最短路径的前瓦片pret
    while(true)
    {
        Position u;//当前选定顶点的坐标
        u.x=-1;
        u.y=-1;
        int min_dist=INF;//当前离源点最近的路径点的距离
        
        //开始寻找最近的路径点
        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                if(!visited[i][j]&&dist[i][j]<min_dist)
                {
                    cout<<"找到一个点"<<endl;
                    min_dist=dist[i][j];
                    u.x=j;
                    u.y=i;
                }
            }
        }
        //假如已经没有再联通的点了,直接退出循环
        if(u.x==-1&&u.y==-1)
        {
            for(int i=0;i<9;i++)
            {
                for(int j=0;j<9;j++)
                {
                    if(dist[i][j]==INF)
                    {
                        pret[i][j].x=-1;
                        pret[i][j].y=-1;
                    }
                }
            }
            break;
        }

        visited[u.y][u.x]=true;

        //否则，用选择好的点，进行松弛
        for(int i=-1;i<=1;i++)
        {
            int j=0;   
            if(i==-1)
            {
                if(dist[u.y][u.x]+1<dist[u.y+i][u.x+j])//因为此时的tilemap权值(距离)暂且用1代替
                {
                    dist[u.y+i][u.x+j]=dist[u.y][u.x]+1;
                    pret[u.y+i][u.x+j].x=u.x;
                    pret[u.y+i][u.x+j].y=u.y;
                }
            }
            else if(i==0)
            {
                j=-1;
                while(j<=1)
                {
                    if(dist[u.y][u.x]+1<dist[u.y+i][u.x+j])//因为此时的tilemap权值(距离)暂且用1代替
                    {
                        dist[u.y+i][u.x+j]=dist[u.y][u.x]+1;
                        pret[u.y+i][u.x+j].x=u.x;
                        pret[u.y+i][u.x+j].y=u.y;
                    }
                    j++;
                    j++;  
                }
            }
            else if(i==1)
            {
                j=0;
                if(dist[u.y][u.x]+1<dist[u.y+i][u.x+j])//因为此时的tilemap权值(距离)暂且用1代替
                {
                    dist[u.y+i][u.x+j]=dist[u.y][u.x]+1;
                    pret[u.y+i][u.x+j].x=u.x;
                    pret[u.y+i][u.x+j].y=u.y;
                }
            }
        }
    }
    cout<<"迪杰斯特拉函数结束了";
    return pret;
};

//这是个用来测试path路径的函数
void testPath(positionList *path)
{
    while(path!=nullptr)
    {
        cout<<path->position.x<<endl<<path->position.y;
        path=path->next;
    }
    cout<<endl;
};


positionList *getPath(Position (*p)[9],Position beginPosition,Position endPosition)
{
    cout<<"进入getpath函数了";
    //先判断点可不可达：
    if(p[endPosition.y][endPosition.x].x==-1 || p[endPosition.y][endPosition.x].y==-1)
    {
        cout<<endl;
        cout<<"点不可达";
        return nullptr;
    }
    

    Position check=endPosition;//一个可以复利用的Position指针

    //这个地方逻辑上错了，checkpath最开始指向了begin，但真正的路径回溯是从end开始的
    //所以我认为，应该设置pathNode应该设置两个指针，一个指向前驱，方便从end创建，一个指向后继，方便遍历。
    PathNode *Pathbegin=new PathNode;
    Pathbegin->position=endPosition;
    while(check.x != beginPosition.x   ||  check.y != beginPosition.y)
    {
        Pathbegin->pre=new PathNode;
        PathNode *tmp=Pathbegin;
        Pathbegin=Pathbegin->pre;
        Pathbegin->next=tmp;

        Pathbegin->position=p[check.y][check.x];
        check=p[check.y][check.x];
    }
    testPath(Pathbegin);
    delete[] p;

    return Pathbegin;
}

void deletPathList(PathNode *begin)
{
    PathNode *cur=begin;
    while(cur!=nullptr)
    {
        PathNode *tmp=cur;
        cur=cur->pre;
        delete tmp;
    }
}