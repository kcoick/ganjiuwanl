/*
    这个文件用于实现迪杰斯特拉算法，迪杰斯特拉算法是一种寻路算法，本文件的迪杰斯特拉
是朴素迪杰斯特拉算法。
    我觉得，既然它是寻路算法，那就一定和地理位置有关，因此我打算只包含MapChunkAndMapTileFormal.h
头文件，这个头文件包含了Tool头文件，所以不用重复包含。
    另外，我还要插一嘴，朴素的迪杰斯特拉算法其实最主要是更新最短路径，暴力循环，没有那么强的方向性。
    在MapChunkAndMapTileFormal.h文件中，有一个tile结构体，这就是瓦片，我们主要根据瓦片来进行最短
寻路。

*/





#ifndef DIJISTRASELF_H
#define DIJISTRASELF_H

#include<iostream>
#include"../../Data/mapchunkData/MapChunkAndMapTileFormal.h"

//这是个路径结构体，相当于一个position链表
typedef struct positionList
{
    Position position;
    positionList *next=nullptr;
    positionList *pre=nullptr;
}PathNode;

//这个是生成所有到目标点前进行松弛操作后的前点函数
Position (*originDijikstra_pret(tile tilemap[][9],Position peoplePosition))[9];

//这是个用来测试path路径的函数
void testPath(positionList *path);


//这个是为了给一个点，通过前点二维position数组得出从当前路径到目标点
positionList *getPath(Position (*p)[9],Position beginPosition,Position endPosition);

//这是个专门用来释放pathList的函数,注意，一般是遍历完后从后往前删
void deletPathList(PathNode *begin);


#endif