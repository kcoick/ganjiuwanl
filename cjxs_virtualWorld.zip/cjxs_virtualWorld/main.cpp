#include <iostream>
#ifdef _WIN32
#include <windows.h>
#endif
#include"narratorH/narrator.h"
#include"mapRender/mapRenderH/mapRender.h"
#include"movitationChoiceH/movitationChoice.h"
#include"Data/Data.h"
#include"agent/agent.h"
using namespace std;
int main()
{
    #ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8); //设置控制台输出为UTF‑8
    #endif
    system("pause");
    //-------以上部分为配置utf-8字符--------
    cout<<"你好，世界！！！"<<endl;
    printPartingLine();
    cout<<"这是一个测试"<<endl;
    cout<<"这是大地图测试";
    initMap();
    printPartingLine();
    cout<<"这是地图块选择与地图块展示的互动";
    printPartingLine();
    mapchunkchoice();
    printPartingLine();
    cout<<"这是个关于字符集的测试"<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"▲";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"▌";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"/";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<".";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"~";
    }
    cout<<endl;

    printPartingLine();

    cout<<"这是个agent自动寻路的测试"<<endl;
    string n="鸿钧";
    string social="测试人";
    person hongjun(n,1,social,0,0,100,100,100,100);

    printPeoplePosition(hongjun.name,hongjun.position);

    printPartingLine();
    
    Position begin=hongjun.position;
    Position end;
    end.x=7;
    end.y=6;
    move(&mapchunk0,&hongjun,begin,end);
    return 0;
}