#ifndef PERSON_H
#define PERSON_H

#include<iostream>
#include<string>
#include"../../Tool/ToolH/tool.h"

/*
当我写这段代码时，正处于地图块中的瓦片可实例化的时候，虽然只弄了mapchunk0，但我可以以此为基石，进行对person的测试

我打算先实现person类的觅食功能(人是铁饭是钢!!!),具体如下:
先设置一个饱食度，再设定一个饥饿值，当饱食度低于饥饿值时，触发觅食逻辑
觅食逻辑:
1.对于觅食逻辑，实现的前提是地图上有食物，所以瓦片实例化先给几个食物，
2.然后是自动寻路逻辑，对于自动寻路逻辑，我打算先用最优解做测试,下面是这个问题的分析:
    首先是瓦片结构要做适配，因为瓦片此时并未设置互相联通的逻辑。对于适配，我觉得
    那当然是图的数据结构啦：
    首先，我认为瓦片应该优化为无向图。因为路是可前后走的
    其次，对于图的存储问题，我认为应该用邻接多重表来优化瓦片结构(这个地方需要着重学习一下,ok,这里直接跳转mapchunkData)



    现在是写完上面这段话的十天之后，我发现图的数据结构并不可行，其实，只需要创建一个二维数组便可以解决全部问题，目前正处于
    考研很关键的阶段，我也终于弄清楚了朴素的迪杰斯特拉算法的实现，在这个过程中，我并未对项目进行任何的修改和进展，现在，让
    我们来构想一下项目的下一步：
        首先我发现了position有点问题，我建议直接用tool头文件中的Position结构体
        其次，让我们来讨论一下寻路算法的问题，我打算把本项目的所有算法都写在一个文件夹里，这个文件夹里放不同的算法文件，每
    个算法文件实现一种功能，远了不说，先来实现朴素迪杰斯特拉算法。

    2026.9.12
        目前已经完成了迪杰斯特拉算法的实现，在algorithm\DijistraSelf模块之中，下一步，我准备进行创建一个小人，这个小人通过迪
    杰斯特拉算法进行对全地图的智能搜索来移动去寻找食物。我觉得，接下代码需要改动的地方是这些：
        1.需要改动地图框架.h文件和人类.h文件的包含关系。
        我觉得，首先，dijistra算法应被person.h包含，这合乎逻辑。但是mapchunkandmaptileformal.h文件也应该包含dijistra算法
    ，因为这个算法本质就是对路径的判断。所以，最好的办法就是新建一个文件摸块:移动(move)
        ok，刚刚
*/
class person//人类
{
    public:
        person(std::string n,int gen,std::string social,int posi1,int posi2,int heal=100,int hun=50,int QI=50,int QE=50);//人类的构造函数
        std::string name;
        Position position;//人的位置，包含两层（完整应包含三层，待修改），第一层是地图块，第二层是瓦片
    protected:
        int bag[10];//背包属性，待修改
    private:
        int gender;//性别
        int health;//健康
        int hungry;//饥饿值
        std::string socialId;//社会身份
        int IQ;//智商
        int EQ;//情商
        
};

#endif