#include"person.h"
using namespace std;

person::person(std::string n,int gen,std::string social,int posix,int posiy,int heal,int hun,int QI,int QE)//人类的构造函数
{
    name=n;
    gender=gen;
    socialId=social;
    health=heal;
    hungry=hun;
    IQ=QI;
    EQ=QE;
    position.x=posix;
    position.y=posiy;
}