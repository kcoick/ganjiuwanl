#ifndef MAPCHUNK0_H
#define MAPCHUNK0_H

#include"../MapChunkAndMapTileFormal.h"

extern MapChunk mapchunk0;//该地图块的类实例
extern initTilesStrategy mapchunk0TilesStrategy;//为了实现具体的实例具体的进行构造故使用了多态构造内部瓦片
extern vector<string> tileMap0;//该地图块内部瓦片的地形视图
#endif
