#include"MapChunkAndMapTileFormal.h"
using namespace std;

vector<string> tileLandform={"▲","▌","/",".","~"};//瓦片的地理类型定义
//---------------------以下部分inittiles函数的默认实现方式(仅用于测试)------------------------

void initTilesStrategy:: initTilesFunc(tile tiles[],vector<string> tilesView,string tileLandfor,int tilePersonN,int tileSrtuctureN,int position)//初始化瓦片结构体数组,使用了虚函数，实现重写(专业叫多态)。
{
    for(int i=0;i<81;i++,position++)
    {
        tiles[i].landForm=tilesView[i];
        tiles[i].tilePosition=tilePositionCalculate(position);
        tiles[i].tilePersonNumber=tilePersonN;
        tiles[i].tileStructureNumber=tileSrtuctureN;
    }
}


//---------------------以下部分是MapChunk的定义------------------------

MapChunk::MapChunk(int personN,int structureN,int foodN,string nam,string mType,vector<string> tilesView,initTilesStrategy &initTilesFun)//整个地图块的构造函数
{
        personNumber=personN;//人类数量
        structureNumber=structureN;//建w筑数量
        name=nam;//该地图块的名字
        foodNumber=foodN;//该地土块粮食产出
        mapType=mType;//地图块自然类型
        initTilesView(tilesView);//初始化内部的地理地形视图-vector<string> allTilesView;
        initTiles=&initTilesFun;//对构建策略进行写入
        initTiles->initTilesFunc(this->Tiles,this->allTilesView);//进行内部tiles构建
}


void MapChunk:: showMapChunk()//显示地图块(测试用)
{
    cout<<endl;
    cout<<"该地图块名字:"<<name<<endl;
    cout<<"该地图块主要自然类型:"<<mapType<<endl;
    cout<<"人类数量:"<<personNumber<<endl;
    cout<<"建筑数量:"<<structureNumber<<endl;
    
    cout<<endl;
    cout<<"该地图块资源产出:"<<endl;
    cout<<"食物产出:"<<foodNumber<<endl;
    
}

void MapChunk::initTilesView(vector<string> TilesView)//初始化所有tiles的地形预览
    {
        allTilesView=TilesView;
    }
MapChunk:: ~MapChunk()//此模板的虚构函数
    {
        ;
    }