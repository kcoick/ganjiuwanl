
#ifndef MAPCHUNKANDMAPTILEFORMAL_H
#define MAPCHUNKANDMAPTILEFORMAL_H
#include<iostream>
#include<string>
#include<vector>
#include"../person/person.h"
#include"../../Tool/ToolH/tool.h"
using namespace std;



/*

先是瓦片的框架：
首先，瓦片大小的定义是1平方公里.且打算用结构体实现瓦片进行实验，
此外，瓦片结构体应以结构体数组的方式存在于地图块中

1.瓦片的自然地形：
自然地形类型应包含5种
山脉，陡壁，缓坡，土地，河流
其中,山脉:▲陡壁:▌缓坡:/平原:.河流:~用这几个字符代替

2.瓦片的土壤信息(待填充)

3.瓦片中的人类信息
为用于测试，目前想先做人类的数量，其余的可交互选项代填。

4.该瓦片上的生物信息(待填充)

5.该瓦片上的建筑信息
打算将该瓦片上的建筑做成结构体数组，可以显示该瓦片建筑信息....(具体放在建筑数据文件中进行定义与实现)
为了测试方便，先将建筑信息作为建筑数量进行实现

6.瓦片的位置信息
为了让游玩者有清晰的视觉体验(这里纯粹扯淡)，应以编号的方式方便游玩者选择与哪个地图块交互。
*/


extern vector<string>tileLandform;//可能的瓦片地理类型声明
//地图瓦片结构体
struct tile
{
    string landForm;//
    int tilePersonNumber;
    int tileStructureNumber;
    Position tilePosition;

};

//下面是一个抽象接口，为了方便初始化地图块中所有瓦片，这是一个策略，由此不用继承原有的类再重写类了，只需要继承重写这个结构体即可
struct initTilesStrategy{
    virtual ~initTilesStrategy()=default;//析构函数，因为是指针写的，所以一定要加析构函数
    virtual void initTilesFunc(tile tiles[],vector<string> tilesView,string tileLandfor="?",int tilePersonN=0,int tileSrtuctureN=0,int position=0);//初始化瓦片结构体数组,使用了虚函数，实现重写(专业叫多态)
};

/*
这是地图块内部的框架，打算用struct和class实现

1.首先是地图块内格子的数量：
格子的数量应该是不少的，但由于技术限制及测试考虑，暂且定为81个
考虑使用两个汉字字实现


2.地图块建筑信息
应包含什么建筑，建筑效果
我打算先不包含，因为不确定建筑应为结构体还是类



3.天气信息（待填充）


4.地图块内人类信息
每一个地图块上都有人类
包含人类的数量
只做一个可以和此人进行互动的入口

5.地图块名称
尽量文雅或狂放

6.地图块内生物信息（包含植物与动物）（待填充）

7.地图块收益
先只包含粮草

8.这是关于类包含一个抽象(虚)接口(结构体)实现多个函数重构的方法(虚函数都在结构体里)：
注意，我认为，对于整个地图块内瓦片的构建，应该是具体问题具体分析的，这样才能实现效率的最大化，
为此，我决定学习一个函数定义，多重实现的方法。(新东方网太差了什么时候才能狠狠地爽爽的开发啊)
下面是学习笔记:
首先，想要实现一个函数中参数列表不同不现实，因为c++规定函数在声明时签名(函数名和参数列表)就确
定了，所以只能用已有的签名。
其次，这个接口(结构体)本质是结构体，(我不确定结构体有没有继承机制，但虚接口就是这样)所以每个要
正式实现虚接口的结构体都要继承(暂且这么说吧)并且重新写个名字，比如mapchunkvitrual_0:mapchunkvirtual
最后，在类框架的定义中，该接口将作为一个结构体指针的形式存在，在具体文件中，则需要先定义好用了接口的结
构体，然后定义一个实例，将这个实例的&赋值给这个指针。 
以下是一个例子:
struct Logical
{
    virtual ~Logical()=default;
    virtual void printWord()=0;
}                     
struct LogicalA:Logical
{
    ~Logical(){cout<<"LogicalA has defaulted"}
    void printWord(){cout<<"LogicalA is running."}
}
struct LogicalB:Logical
{
    ~Logical(){cout<<"LogicalB has defaulted"}
    void printWord(){cout<<"LogicalB is running."}
}
此外还要注意:
1. `virtual void foo();` 普通虚函数：基类有实现，子类可以选择重写，也可以不重写。
2. `virtual void foo() = 0;` **纯虚函数**：基类没有实现；只要有它，这个类就变成抽象类，**不能直接实例化对象**，子类必须重写，否则子类也不能实例化。


9.展示地图块内部的函数
应当包含展示整个地图块的信息和地图块内部的构成功能
其次，应该做好解耦。
*/

//地图块类
class MapChunk
{
    public:
    
        MapChunk(int personN,int structureN,int foodN,string nam,string mType,vector<string> tilesView,initTilesStrategy &initTilesFunc);//整个地图块的构造函数
        vector<string> revenue={"食物"};//地区收益名称
        void showMapChunk();//显示地图块(测试用)

        tile Tiles[81];//地图内部瓦片结构体数组(土地属于人民!!!)
        vector<string> allTilesView;//所有瓦片地形的预览，方便进行瓦片初始化
        void initTilesView(vector<string> TilesView);//初始化所有tiles的地形预览
        initTilesStrategy *initTiles;
        /*
              
        */
        ~MapChunk();//此类的虚构函数
    protected:
        
    
    private:
        int tileNumber=81;//瓦片数量
        int personNumber;//人类数量
        int structureNumber;//建筑数量
        string name;//该地图块的名字
        int foodNumber;//该地土块粮食产出
        string mapType;//地图块自然类型
};

#endif