#ifndef DATA_H
#define DATA_H

#include"mapchunkData/MapChunkData.h"
#include"./mapData/mapTypeData.h"
#include"./person/person.h"

#endif