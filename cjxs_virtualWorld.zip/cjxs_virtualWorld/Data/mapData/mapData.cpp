
#include"mapTypeData.h"


std::vector<std::string> mapType={"山脉","丘陵","平原","湖泊","河流","谷地"};


