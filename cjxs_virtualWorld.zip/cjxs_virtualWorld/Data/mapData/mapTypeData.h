#ifndef MAPTYPEDATA_H
#define MAPTYPEDATA_H
#include<iostream>
#include<string>
#include<vector>
using namespace std;

vector<string> getMapTypeData(int &outsize);
extern vector<string>mapType;

#endif