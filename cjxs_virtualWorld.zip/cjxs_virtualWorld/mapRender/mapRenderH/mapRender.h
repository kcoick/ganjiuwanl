/*
本文件作用是初始化,并显示所有的地图
包含了mapTypeData(地图类型),narrator(旁白),Data(数据)模块
目前只做了荆鄂地区地图

新加功能:
渲染地图块内部地理地形:showMapTilesView(tile tileView[]);
(说实话，我并不确定是否应该把地图块的渲染函数写在render模块里
我打算先这样写着，作为测试。随时准备改回来。)
*/


#ifndef MAPRENDER_H
#define MAPRENDER_H

#include"../../Data/Data.h"
#include"../../narratorH/narrator.h"


void initMap();//初始化地图

void showMap();//显示地图(仅仅只针对于沅鄂地区，等待全世界地图开发)

void showMapTilesView(tile tileView[]);//渲染地图块内部的函数

extern int mapRendernum;//这个变量用于position，配合自增函数方便开发


#endif