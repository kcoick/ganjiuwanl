#include"../mapRenderH/mapRender.h"
int mapRendernum=0;//这个变量用于position，配合自增函数方便开发
void initMap()//初始化地图
{   //第一行
    
    printMapCell(mapType[0],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[1],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[1],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[0],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[0],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[0],mapRendernum,1);
    mapRendernum=numberAddOne(mapRendernum);

    //第二行
    
    printMapCell(mapType[4],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[3],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[1],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[3],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[4],mapRendernum,1);
    mapRendernum=numberAddOne(mapRendernum);
    
    //第三行
 
    printMapCell(mapType[1],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[4],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[4],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[4],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[4],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum,1);
    mapRendernum=numberAddOne(mapRendernum);
    
    //第四行

    printMapCell(mapType[4],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[0],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum,1);
    mapRendernum=numberAddOne(mapRendernum);
    
    
    //第五行

    printMapCell(mapType[3],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[0],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[0],mapRendernum,1);
    mapRendernum=numberAddOne(mapRendernum);
    //第六行
 
    printMapCell(mapType[0],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum);
    mapRendernum=numberAddOne(mapRendernum);

    printMapCell(mapType[2],mapRendernum,1);
    mapRendernum=numberAddOne(mapRendernum);
}

void showMapTilesView(tile tileView[])//渲染地图块内部的函数
{
    for(int i=0;i<81;i++)
    {
        if((i+1)%9==0)
        {   
            printMapCell(tileView[i].landForm,i,1);
        }
        else
        {
            printMapCell(tileView[i].landForm,i,0);
        }
    }
}