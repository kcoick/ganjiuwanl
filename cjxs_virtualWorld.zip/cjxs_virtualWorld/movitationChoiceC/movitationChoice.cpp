#include"../movitationChoiceH/movitationChoice.h"
#include<iostream>
using namespace std;

int mapchunkchoice()
{
    int choice;
    cout<<"请选择你要进行行动的地块:";//进行选项询问并引导
    cin>>choice;
    printPartingLine();

    switch(choice)//判断地块选择,随后展示地块(以展示地块信息为测试),并开始对于地块的行动选择
    {
        case 0:mapchunk0.showMapChunk();showMapTilesView(mapchunk0.Tiles);break;
        case 1:mapchunk0.showMapChunk();break;
        case 2:mapchunk0.showMapChunk();break;
        case 3:mapchunk0.showMapChunk();break;
        case 4:mapchunk0.showMapChunk();break;
        case 5:mapchunk0.showMapChunk();break;
        case 6:mapchunk0.showMapChunk();break;
        case 7:mapchunk0.showMapChunk();break;
        case 8:mapchunk0.showMapChunk();break;
        case 9:mapchunk0.showMapChunk();break;
        case 10:mapchunk0.showMapChunk();break;
        case 11:mapchunk0.showMapChunk();break;
        case 12:mapchunk0.showMapChunk();break;
        case 13:mapchunk0.showMapChunk();break;
        case 14:mapchunk0.showMapChunk();break;
        case 15:mapchunk0.showMapChunk();break;
        case 16:mapchunk0.showMapChunk();break;
        case 17:mapchunk0.showMapChunk();break;
        case 18:mapchunk0.showMapChunk();break;
        case 19:mapchunk0.showMapChunk();break;
        case 20:mapchunk0.showMapChunk();break;
        case 21:mapchunk0.showMapChunk();break;
        case 22:mapchunk0.showMapChunk();break;
        case 23:mapchunk0.showMapChunk();break;
        case 24:mapchunk0.showMapChunk();break;
        case 25:mapchunk0.showMapChunk();break;
        case 26:mapchunk0.showMapChunk();break;
        case 27:mapchunk0.showMapChunk();break;
        case 28:mapchunk0.showMapChunk();break;
        case 29:mapchunk0.showMapChunk();break;
        case 30:mapchunk0.showMapChunk();break;
        case 31:mapchunk0.showMapChunk();break;
        case 32:mapchunk0.showMapChunk();break;
        case 33:mapchunk0.showMapChunk();break;
        case 34:mapchunk0.showMapChunk();break;
        case 35:mapchunk0.showMapChunk();break;
        default:cout<<"输入错误，请重新输入";
    };

    return 0;
};

