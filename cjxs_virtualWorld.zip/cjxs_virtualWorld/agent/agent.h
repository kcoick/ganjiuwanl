/*
这个文件是封装所有小人行为逻辑和决策树的
目前正在写move逻辑，我已经迫不及待了，赶紧开始吧

*/
#ifndef AGENT_H
#define AGENT_H

#include"agent_move/agent_move.h"

#endif