/*
坏菜了我去，mapchunkformal是tile[81]，originDijikstra_pret里是tile[9][9]

我打算这样解决这个问题

现在想好了，本来用一维数组存储tiles就没问题，新建一个二维变量然后  映射一下就可以啦。


今天把dijisktra改正确了，除此之外，在move函数中写到了路径，剩下改变人物位置和narrator
模块适配了，最后，千万千万！！！！记得释放内存！！！

今天把move函数实现了，但是并未把move与trick适配，因为path本质上需要早日释放，无法与其他小人
同时存在path。我的解决办法是这样的创建决策树时，把path作为小人的暂时想法存储进去，影响决策判断。
*/



#include"agent_move.h"

void move(MapChunk *m,person *p,Position begin,Position end)
{
    cout<<"进入move函数了"<<endl;
    Position (*pre)[9];
    
    tile tilemap[9][9];
    //开始映射
    for(int i=0;i<81;i++)
    {
        Position p=tilePositionCalculate(i);
        tilemap[p.y][p.x]=m->Tiles[i];
    }
    
    
    pre=originDijikstra_pret(tilemap,begin);
    positionList *path=getPath(pre,begin,end);//得到路径


    //如果路径不存在，返回空指针，打印日志
    if(path==nullptr)
    {
        cout<<"指针不存在";
        printPeopleDontHavePath(p->name);
        return;
    }

    //开始改变
    while(path!=nullptr)
    {
        p->position=path->next->position;
        printPeoplePositionChange(p->name,path->position,path->next->position);
        path=path->next;
    }

    deletPathList(path);
    //最后测试一下小人的位置
    printPartingLine();
    printPeoplePosition(p->name,p->position);

}