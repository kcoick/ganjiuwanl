/*
这个文件目的是解决玩家的行动选项问题
我打算这样做：
以离散的数字给出玩家可以进行行动的选项
以函数的方法获得玩家想要的行动选项
最后返回选项值

此外，我打算在这个文件中调用玩家选项所对应的函数入口
但不太确定这会不会导致项目耦合度太高，因此先做测试


这是这个文件所定义的函数说明：

首先是选择哪个地图块mapchoice()：
对于这个函数给出地图块的选择范围
然后进行选择
最后进入mapData.h进行对该地图的操作
注意，对于地图块的操作还未开始开发，所以应只展示地图块的信息
*/


#ifndef MOVITATION_H
#define MOVITATION_H

#include<iostream>
#include"../Data/Data.h"
#include"../narratorH/narrator.h"
#include"../mapRender/mapRenderH/mapRender.h"


int mapchunkchoice();//大地图选择

#endif