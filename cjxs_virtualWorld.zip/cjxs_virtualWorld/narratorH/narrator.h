#ifndef NARRATOR_H
#define NARRATOR_H

#include"../Tool/ToolH/tool.h"
#include<string>
using namespace std;
void printPartingLine();//行动分割线
void printMapCuttingLineLeft();//地图分割线(左)
void printMapCuttingRight();//地图分割线(右)
void printMapCuttingup();//地图分割线(上)
void printMapCuttingdown();//地图分割线(下)
void printMapCell(string name,int position,bool Enter=0);//打印地图中的一个小格子，包含了打印分割线的功能和回车换行功能

//-----------这是一些关于小人的解释性旁白，或者说日志---------------------

void printPeoplePositionChange(std::string name,Position begin,Position end);//打印小人的位置变化
void printPeopleDontHavePath(std::string name);//打印小人无路可达终点的日志
void printPeoplePosition(std::string name,Position position);//打印小人的位置日志，可与别的日志组合使用

//-----------这里是小人旁白或者说日志的结束------------------------------
#endif