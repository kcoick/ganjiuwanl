#include <iostream>
#ifdef _WIN32
#include <windows.h>
#endif
#include"narratorH/narrator.h"
#include"mapRender/mapRenderH/mapRender.h"
#include"movitationChoiceH/movitationChoice.h"
#include"Data/Data.h"
#include"agent/agent.h"
using namespace std;
int main()
{
    #ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8); //设置控制台输出为UTF‑8
    #endif
    system("pause");
    //-------以上部分为配置utf-8字符--------
    cout<<"你好，世界！！！"<<endl;
    printPartingLine();
    cout<<"这是一个测试"<<endl;
    cout<<"这是大地图测试";
    initMap();
    printPartingLine();
    cout<<"这是地图块选择与地图块展示的互动";
    printPartingLine();
    mapchunkchoice();
    printPartingLine();
    cout<<"这是个关于字符集的测试"<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"▲";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"▌";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"/";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<".";
    }
    cout<<endl;
    for(int i=0;i<10;i++)
    {
        cout<<"~";
    }
    cout<<endl;

    printPartingLine();

    cout<<"这是个agent自动寻路的测试"<<endl;
    string n="鸿钧";
    string social="测试人";
    person hongjun(n,1,social,0,0,100,100,100,100);

    printPeoplePosition(hongjun.name,hongjun.position);

    printPartingLine();
    
    Position begin=hongjun.position;
    Position end;
    end.x=7;
    end.y=6;
    move(&mapchunk0,&hongjun,begin,end);
    return 0;
}

/*
现在是第九版本。 
目前任务4，已经完成了，中间经过了比较曲折的过程。
我发现，尽量不要用同名文件夹去嵌套工程文件夹，不然
会导致文件初始化顺序不清晰的问题，导致引用变量时，
发生未定义情况。
目前想实现小人的自主觅食的功能，但是必须要经过tick
也就是总体时间的构建，让所有的功能根据这个总体时间
来进行顺序执行。
问了问豆包，给了我一大堆。但有个信息特别有用。就是
把move函数拆成调用dijikstra函数和getpath函数的寻找
食物函数，与控制小人坐标移动的寻路函数。
总之，我打算这样做：
1.先扩展map类，让食物增加逻辑加进去
2.然后改写move函数，让寻找食物函数和移动函数分开。
3.将新加的两个函数添入agent.h头文件中
4.在person类中加入task结构体。
5.为了测试方便，暂且以饱食度的降低程度作为欲望的判
断标准来激活寻找食物函数和移动函数，并最终将觅食路
径和进食任务加入task中
*/