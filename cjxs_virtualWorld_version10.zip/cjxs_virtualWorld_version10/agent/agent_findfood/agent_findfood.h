#ifndef AGENT_FINDFOOD_H
#define AGENT_FINDFOOD_H

#include"../../algorithm/DijistraSelf/DijistraSelf.h"
#include"../../narratorH/narrator.h"
#include"../../Data/Data.h"

extern int stepP;//瓦片位置据离源瓦片的步数
int lookAroundForFood(MapChunk *m,person *h,int beginP,int step=0,int predir);//模拟小人环顾四周看食物的动作
positionList findFood(MapChunk *m,person *h,Position begin);//一个寻找食物生成最短路径的函数



#endif