#include"agent_findfood.h"
//一个寻找食物生成最短路径的函数
/*
这个函数分为两个部分：
第一部分为寻找距离当前瓦片最近一个存在食物的瓦片（非权值和即距离最近，仅为下标最近）
第二部分为生成距离该瓦片权值和(即距离)最近的一条路径。
*/

//模拟小人环顾四周看食物的动作,step变量是距离小人所在瓦片的步数传入0即可,predir是来的方向，比如若为0(北方)就不再向0(北方)遍历，若为3(西方)，就不再向3(西方)遍历
int stepP;
int lookAroundForFood(MapChunk *m,person *h,int beginP,int step,int predir)
{
    stepP=step;//先记录步数
    int targetP=-1;//有食物的瓦片的下标值

    if(m->Tiles[beginP].foodNumber>0)
    {
        return beginP;
    }

    if(step==0)
    {
        
        if(beginP+ListDirection[0]>-1)
        {targetP=lookAroundForFood(m,h,beginP+ListDirection[0],step+1,2);}
        if((beginP+ListDirection[1])%9!=0)
        {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[1],step+1,3);}
        if(beginP+ListDirection[2]<81)
        {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[2],step+1,0);}
        if((beginP+ListDirection[3])%9!=8&&(beginP+ListDirection[3])!=-1)
        {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[3],step+1,1);}
    }
    else
    {
        int d=0;
        while(d<4)
        {
            if(d==predir)
            {
                continue;
            }
            switch(d)
            {
                case 0:if(beginP+ListDirection[0]>-1)
                {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[0],step+1,2);}break;
                case 1:if((beginP+ListDirection[1])%9!=0)
                {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[1],step+1,3);}break;
                case 2:if(beginP+ListDirection[2]<81)
                {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[2],step+1,0);}break;
                case 3:if((beginP+ListDirection[3])%9!=8&&(beginP+ListDirection[3])!=-1)
                {int tmpP=lookAroundForFood(m,h,beginP+ListDirection[3],step+1,1);}break;
            }
            d++;
        }
    }
    return targetP;
};





positionList findFood(MapChunk *m,person *h,Position begin)
{
    Position (*pre)[9];
    
    tile tilemap[9][9];
    //开始映射
    for(int i=0;i<81;i++)
    {
        Position p=tilePositionCalculate(i);
        tilemap[p.y][p.x]=m->Tiles[i];
    }
    int targetList=PositionToList(begin);
    Position end;
    for(int i=targetList;i<80;i++)
    {
        if(m->Tiles[i].foodNumber>0)
        {
            break;
        }
    }
    
    
    
    pre=originDijikstra_pret(tilemap,begin);
    positionList *path=getPath(pre,begin,end);//得到路径


    //如果路径不存在，返回空指针，打印日志
    if(path==nullptr)
    {
        cout<<"指针不存在";
        printPeopleDontHavePath(h->name);
        return;
    }
}