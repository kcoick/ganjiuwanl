/*
这个文件是用来写小人的移动逻辑的
目前，由于没有引入视觉系统，所以所有小人都是上帝视角，直接寻找最短路径
但是，这里我想做观察者模式，虽然但是(哈哈)，为了尽快测试，还是算了吧。

所以，真正的测试，我打算小人先每走一步，用narrator在函数中说“...移动到了...”
*/

#ifndef AGENT_MOVE_H
#define AGENT_MOVE_H


#include"../../narratorH/narrator.h"
#include"../../Data/Data.h"
#include"../../algorithm/DijistraSelf/DijistraSelf.h"

void move(MapChunk *m,person *h,Position begin,Position end);

#endif