/*
    注意，这里新学习了一种返回二维数组指针的方法，如果忘了，记得去查查这个：
struct Point { int x; int y; };

Point (*create2D())[3]
{
    // 分配2个元素，每个是 Point[3]
    Point(*p)[3] = new Point[2][3]{
        { {1,1}, {2,2}, {3,3} },
        { {4,4}, {5,5}, {6,6} }
    };
    return p;
}

int main()
{
    Point(*ptr)[3] = create2D();
    printf("%d\n", ptr[0][1].x);

    // 必须手动释放！
    delete[] ptr;
    return 0;
}
*/

#include"DijistraSelf.h"

//这个是用来测试打印二维的pre路径数组的
void testPret(Position testpret[9][9])
{
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<9;j++)
        {
            cout<<"pret中的元素分别是"<<testpret[i][j].x<<" "<<testpret[i][j].y<<endl;
        }
    }
}

Position (*originDijikstra_pret(tile tilemap[][9],Position peoplePosition))[9]
{
    cout<<"进入迪杰斯特拉函数了";
    const int INF=INT_MAX/2;
    int dist[9][9];//当前最短路径,注意，在实现过程中第一个为行数，列的值，第二个为列数，行的值
    Position (*pret)[9]=new Position[9][9];//前一个瓦片的位置
    bool visited[9][9]={false};//当前顶点是否访问过,避免浪费时间
    //对dist和visited进行初始化
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<9;j++)
        {
            dist[i][j]=INF;
            pret[i][j].x=-1;
            pret[i][j].y=-1;
        }
    }
    dist[peoplePosition.y][peoplePosition.x]=0;
    pret[peoplePosition.y][peoplePosition.x].y=peoplePosition.y;
    pret[peoplePosition.y][peoplePosition.x].x=peoplePosition.x;
    //开始求每个最短路径的前瓦片pret
    while(true)
    {
        Position u;//当前选定顶点的坐标
        u.x=-1;
        u.y=-1;
        int min_dist=INF;//当前离源点最近的路径点的距离
        
        //开始寻找最近的路径点
        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                if(!visited[i][j]&&dist[i][j]<min_dist)//这里的<不能加=号，因为防止找一个不联通的点，错过退出循环的条件(当dist[0]做松弛时，就已经存在小于INF的点了)
                {
                    cout<<"找到一个点"<<endl;
                    min_dist=dist[i][j];
                    u.x=j;
                    u.y=i;
                }
            }
        }
        //假如已经没有小于INF的点了
        if(u.x==-1&&u.y==-1)
        {
            //遍历整个dist数组寻找没有选定或进行过松弛的点
            for(int i=0;i<9;i++)
            {
                for(int j=0;j<9;j++)
                {
                    if(dist[i][j]==INF)
                    {
                        pret[i][j].x=-1;
                        pret[i][j].y=-1;
                    }
                }
            }
            break;
        }
        


        visited[u.y][u.x]=true;
        
        int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};

        //否则，用选择好的点，进行松弛(还要注意是否会数组越界)
        for(int i=0;i<3;i++)
        {
            if(u.x+dir[i][0]>=0&&u.x+dir[i][0]<=8)
            {
                if(u.y+dir[i][1]>=0&&u.y+dir[i][1]<=8)
                {
                    if(dist[u.y][u.x]+tilemap[u.y+dir[i][1]][u.x+dir[i][0]].movement_cost<dist[u.y+dir[i][1]][u.x+dir[i][0]]&&!visited[u.y+dir[i][1]][u.x+dir[i][0]])
                    {
                        dist[u.y+dir[i][1]][u.x+dir[i][0]]=dist[u.y][u.x]+tilemap[u.y+dir[i][1]][u.x+dir[i][0]].movement_cost;
                        pret[u.y+dir[i][1]][u.x+dir[i][0]].y=u.y;
                        pret[u.y+dir[i][1]][u.x+dir[i][0]].x=u.x;
                    }
                }
            }
        }
    }
    cout<<"迪杰斯特拉函数结束了"<<endl;
    testPret(pret);
    return pret;
};

//这是个用来测试path路径的函数
void testPath(positionList *path)
{
    positionList *check=path;
    while(check!=nullptr)
    {
        cout<<check->position.x<<endl<<check->position.y;
        check=check->next;
    }
    cout<<endl;
};


positionList *getPath(Position (*p)[9],Position beginPosition,Position endPosition)
{
    cout<<"进入getpath函数了";
    //先判断点可不可达：
    if(p[endPosition.y][endPosition.x].x==-1 || p[endPosition.y][endPosition.x].y==-1)
    {
        cout<<endl;
        cout<<"点不可达";
        return nullptr;
    }
    

    Position check=endPosition;//一个可以复利用的Position指针

    //这个地方逻辑上错了，checkpath最开始指向了begin，但真正的路径回溯是从end开始的
    //所以我认为，应该设置pathNode应该设置两个指针，一个指向前驱，方便从end创建，一个指向后继，方便遍历。
    PathNode *Pathbegin=new PathNode;
    Pathbegin->position=endPosition;
    while(check.x != beginPosition.x   ||  check.y != beginPosition.y)
    {
        Pathbegin->pre=new PathNode;
        PathNode *tmp=Pathbegin;
        Pathbegin=Pathbegin->pre;
        Pathbegin->next=tmp;

        Pathbegin->position=p[check.y][check.x];
        check=p[check.y][check.x];
    }
    testPath(Pathbegin);
    delete[] p;

    return Pathbegin;
}

void deletPathList(PathNode *begin)
{
    PathNode *cur=begin;
    while(cur!=nullptr)
    {
        PathNode *tmp=cur;
        cur=cur->next;
        delete tmp;
    }
}