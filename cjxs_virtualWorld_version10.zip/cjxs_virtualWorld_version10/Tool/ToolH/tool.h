/*
本文件作用是开发过程中的一些小工具
包含了
bool judgeMoreTen(int x);//判断是否大于10
bool judgeMoreHundred(int x);//判断是否大于100
bool judeMoreTenLessHundred(int x);//判断是否大于10小于100
int judgeNumberDigit(int number);//判断数字位数的函数
string printSpaceForThreeDigitFormal_self(int number);//如果位数小于3位，为了打印出来的垂直效果美观，进行补全然后打印
int numberAddOne(int number);//对数据进行自增操作
struct Position//一个坐标结构体，包含xy坐标
Position tilePositionCalculate(int position);//根据瓦片列表中瓦片的下标计算该瓦片的position
int PositionToList(Position p);//根据psition转化成9*9瓦片列表中的下标
extern int direction[4][2];//一个方向变量，用于计算二维向北东南西，顺序为北东南西
extern int ListDirection[4];//一个方向变量，用于下标的北东南西计算。
int ListdirecNorth(int begin);//这是一个下标减9的函数，返回瓦片列表向北移动一格
int ListdirecEast(int begin);//这是一个下标减9的函数，返回瓦片列表向东移动一格
int ListdirecSourth(int begin);//这是一个下标减9的函数，返回瓦片列表向南移动一格
int ListdirecWest(int begin);//这是一个下标减9的函数，返回瓦片列表向西移动一格
class RandomTool一个随机数类工具，我听从豆包的建议，将随机数功能封装为一个类,具体使用说明如下：先用getEngine创建一个引擎，然后就不用创建引擎了；之后int定义一个变量，令其=randInt(min,max)
void IntIndexExchange(int a,int b,int &c,int &d);//比较函数，如果a>b,则的值为d的值，反之，d的值为c的值

*/


#ifndef TOOL_H
#define TOOL_H

#include<iostream>
#include<string>
#include<random>
using namespace std;

bool judgeMoreTen(int x);//判断是否大于10
bool judgeMoreHundred(int x);//判断是否大于100
bool judeMoreTenLessHundred(int x);//判断是否大于10小于100(喵的，用了半天函数名拼写错了)
int judgeNumberDigit(int number);//判断数字位数的函数
string printSpaceForThreeDigitFormal_self(int number);//如果位数小于3位，为了打印出来的垂直效果美观，进行补全然后打印,主要为了打印空格
int numberAddOne(int number);//对数据进行自增操作，为了防止大规模错误，准备多设置几个这种函数，改的时候只要改函数，大量的错误一步搞定(学到就是赚到！！！)
//以下是一个坐标结构体，包含xy坐标
struct Position
{
    int x;
    int y;
};

Position tilePositionCalculate(int position);//根据瓦片列表中瓦片的下标计算该瓦片的position
int PositionToList(Position p);//根据psition转化成9*9瓦片列表中的下标

extern int direction[4][2];//一个方向变量，用于计算二维向北东南西，顺序为北东南西
extern int ListDirection[4];//一个方向变量，用于下标的北东南西计算。
int ListdirecNorth(int begin);//这是一个下标减9的函数，返回瓦片列表向北移动一格
int ListdirecEast(int begin);//这是一个下标减9的函数，返回瓦片列表向东移动一格
int ListdirecSourth(int begin);//这是一个下标减9的函数，返回瓦片列表向南移动一格
int ListdirecWest(int begin);//这是一个下标减9的函数，返回瓦片列表向西移动一格

//这是一个随机数类，我听从豆包的建议，将随机数功能封装为一个类,具体使用说明如下：
/*
先用getEngine创建一个引擎，然后就不用创建引擎了；之后int定义一个变量，令其=randInt(min,max)
*/
class RandomTool
{
    public:
    static std::mt19937& getEngine();//返回一个随机数引擎变量
    static int randInt(int min,int max);//快速生成范围为[min.max]的随机整数
};

void IntIndexExchange(int a,int b,int &c,int &d);//比较函数，如果a>b,则的值为d的值，反之，d的值为c的值

#endif