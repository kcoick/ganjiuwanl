#include"../ToolH/tool.h"
using namespace std;

bool judgeMoreTen(int x)//判断是否大于10
{
    if(x>=10)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};


bool judgeMoreHundred(int x)//判断是否大于100
{
    if(x>=100)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};


bool judeMoreTenLessHundred(int x)//判断是否大于10小于100
{
    if(x>=10&&x<100)
    {
        return 1;
    }
    else
    {
        return 0;
    }
};

int judgeNumberDigit(int number)//判断数字位数的函数
{
    int digit=0;
    while(number>0)
    {
        number/=10;
        digit++;
    }
    return digit;
};

string printSpaceForThreeDigitFormal_self(int number)//如果位数小于3位，为了打印出来的垂直效果美观，进行补全然后打印,主要为了打印空格
{
    string s="";
    int digit=judgeNumberDigit(number);
    while(digit<3)
    {
        s+=" ";
        digit++;
    }
    return s;
};

int numberAddOne(int number)//对数据进行自增操作，为了防止大规模错误，准备多设置几个这种函数，改的时候只要改函数，大量的错误一步搞定(学到就是赚到！！！)
{
    number++;
    return number;
};

Position tilePositionCalculate(int position)//根据瓦片列表中瓦片的下标计算该瓦片的position
{
    /*
    注意，这个函数一开始写错了，现在已经改过来了
    这个函数用于整型position从0开始映射到二维Position的
    第一个下标--y和第二个下标--x
    */
    Position p;
    p.x=position%9;
    p.y=position/9;
    return p;
}

int PositionToList(Position p)//根据psition转化成9*9瓦片列表中的下标
{
    int l=0;
    l+=p.y*9;
    l+=p.x;
    return l;
}

int direction[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int ListDirection[4]={-9,1,9.-1};
int ListdirecNorth(int begin)//这是一个下标减9的函数，返回瓦片列表向北移动一格
{
    begin-=9;
    return begin;
};
int ListdirecEast(int begin)//这是一个下标加1的函数，返回瓦片列表向东移动一格
{
    begin+=1;
    return begin;
}
int ListdirecSourth(int begin)//这是一个下标加9的函数，返回瓦片列表向南移动一格
{
    begin+=9;
    return begin;
}
int ListdirecWest(int begin)//这是一个下标减1的函数，返回瓦片列表向西移动一格
{
    begin-=1;
    return begin;
}


std:: mt19937& RandomTool::getEngine()
{
    static std::random_device rd;
    static std::mt19937 gen(rd());
    return gen;
}

int RandomTool::randInt(int min,int max)
{
    std::uniform_int_distribution<int> dist(min,max);
    return dist(getEngine());
}

void IntIndexExchange(int a,int b,int &c,int &d)//比较函数，如果a>b,则的值为d的值，反之，d的值为c的值
{
    if(a>=b)
    {
        c=d;
    }
    else
    {
        d=c;
    }
}